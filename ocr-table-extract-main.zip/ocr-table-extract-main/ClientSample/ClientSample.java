import com.owlike.genson.Genson;
import com.owlike.genson.GensonBuilder;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class ClientSample {

    public static void sendOcrRequest(String inputFile, String savePath, String propertyType) {
        try {
            URL url = new URL("http://192.168.124.115:8717/path-ocr");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);

            String jsonInputString = String.format(
                "{\"pdfPath\": \"%s\", \"savePath\": \"%s\", \"propertyType\": \"%s\"}",
                inputFile, savePath, propertyType
            );

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int status = conn.getResponseCode();
            InputStream responseStream = (status < 400) ? conn.getInputStream() : conn.getErrorStream();

            StringBuilder responseBuilder = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(responseStream, "utf-8"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    responseBuilder.append(line.trim());
                }
            }

            Genson genson = new GensonBuilder().create();
            Map<String, Object> resultMap = genson.deserialize(responseBuilder.toString(), Map.class);

            System.out.println("Response Code: " + status);
            System.out.println("결과 코드: " + resultMap.get("resultCode"));
            System.out.println("결과 메시지: " + resultMap.get("resultMessage"));
            System.out.println("저장 경로: " + resultMap.get("savePath"));

        } catch (Exception e) {
            System.err.println("요청 실패: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        String savePath = "/mnt/d/OCR/onbid/upload_data";
        String pdfPath = "../data/더드림 감정평가사사무소_p2201810766A020030012021.pdf";
        String propertyType = "immovable";

        sendOcrRequest(pdfPath, savePath, propertyType);
    }
}